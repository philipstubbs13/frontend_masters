const fs = require('fs');
const through = require('through2');

/* Create a read stream here
const readPoemStream = ???
*/

/* Create a write stream here
const writePoemStream =
*/

/* EXTENSION: Create a transform stream (modify the read stream before piping to write stream)
const transformStream = ???
readPoemStream.pipe(transformStream).pipe(writePoemStream)
*/